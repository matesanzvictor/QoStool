/*################################################################################
# Autor: Víctor Matesanz Cotillas
# Fecha: 11/05/2021
################################################################################*/

#include <math.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include "function1.h"


//VARIABLES
pcap_t  *per= NULL;
pthread_t t;
char *interface;
struct in_addr addr;
unsigned long saddr;
int StartFrame =0;
int packet_size=0;

uint8_t Source_mac[ETH_ALEN]={0};
uint8_t Dest_mac[ETH_ALEN]={0};

long double TableTime[MAX_STRUCTURE] = {0};

struct timeval tv;




void getMacIP()
{
    
    int s;
    struct ifreq ifr;
    s = socket(AF_INET, SOCK_DGRAM, 0);
    strcpy(ifr.ifr_name, interface);
    ioctl(s, SIOCGIFHWADDR, &ifr);
    memcpy(Source_mac,ifr.ifr_hwaddr.sa_data,HWADDR_len);

 	ifr.ifr_addr.sa_family = AF_INET;
 	strncpy(ifr.ifr_name, interface, IFNAMSIZ-1);
 	ioctl(s, SIOCGIFADDR, &ifr);
 	 
 	saddr = inet_addr(inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));

}


void attendPacket(u_char *user,const struct pcap_pkthdr *h,const u_char *packet)
{
 
    uint8_t dest[ETH_ALEN]={0};
    uint8_t src[ETH_ALEN]={0};
    uint16_t tipo;
    uint16_t auxTipo;
    uint8_t IProto;
    uint8_t ICMPtype;
    uint8_t ICMPcode;
    uint16_t Dest_port;
    uint16_t Sequence_number;
    int tamano=0;
   

    memcpy(dest,packet,ETH_ALEN); 
    tamano=tamano+ETH_ALEN;

    memcpy(src,packet+tamano,ETH_ALEN); 
    tamano=tamano+ETH_ALEN;

    memcpy(&tipo,packet+tamano,ETH_TLEN);
    auxTipo=ntohs(tipo);
    
    tamano =23;
    memcpy(&IProto,packet+tamano,1);

    tamano=34;
    memcpy(&ICMPtype,packet+tamano,1);

    tamano=35;
    memcpy(&ICMPcode,packet+tamano,1);

    tamano=40;
    memcpy(&Sequence_number,packet+tamano,2);

    tamano=64;
    memcpy(&Dest_port,packet+tamano,2);

    
   
    if (memcmp(dest,Source_mac,6) ==0 && auxTipo == 0x0806){

		memcpy(Dest_mac,packet+ETH_ALEN,ETH_ALEN);
		
  	}else if(memcmp(dest,Source_mac,6) ==0 && auxTipo == 0x0800 && IProto == 0x01 && ICMPtype == 0x00){

			TableTime[ntohs(Sequence_number)] = (h->ts.tv_usec)*1.0;//microsegundos

  	}else if(memcmp(dest,Source_mac,6) ==0 && auxTipo == 0x0800 && IProto == 0x01 && ICMPtype == 0x03 && ICMPcode == 0x03) {

			TableTime[htons(Dest_port)-33434] = (h->ts.tv_usec)*1.0;

  	}

}

void * Capture(void *arg)
{
    pcap_loop(per,-1,attendPacket,NULL);
    return NULL;
}

void Startcapture(){

    if(pthread_create(&t,NULL,Capture,NULL)!=0){
        printf("fallo al crear el hilo");
    }   

}


int StartProgram(){

    char errbuf[PCAP_ERRBUF_SIZE];

    if((interface = pcap_lookupdev(errbuf))==NULL)
    {
        printf("ERROR %s\n",errbuf);
        return 1;
    }   

    if(StartFrame == 0){

         if((per = pcap_open_live(interface,1514,1,1000,errbuf))==NULL)
            {
                printf("%s\n",errbuf);
                return 1;
                
            }

         StartFrame=1;
         return 0;

    }

    return 1;
}


void Measures(int sent,double RTT[sent],int Interpacket_gap){

	int i;
	long double TableThrough[sent-1];
	long double sum=0;
	long double mean;
	long double BW;
	long double general_BW;
	long double deviation_RTT;
	int packet_loss =0 ;
		 
	int number = 0;
	

	/**************************
	CALCULATION OF PACKET LOSS  
	**************************/

	for(i=0;i<sent;i++){

		if(TableTime[i] <1 ){

			packet_loss++;
			
		}else {

			if(TableTime[i]>1){
				
			}else{

				TableTime[i] = 0.0;
				packet_loss++;
			}
		}
		
	}	


	double TableRTT[sent];
	double RTTaverage;
	long double sumRTT=0;

	/*********************
	CALCULATION OF THE RTT 
	**********************/

	for(i=0;i<sent;i++){

		TableRTT[i] = 0.0;

		if(TableTime[i]!= 0.0 && TableTime[i]>RTT[i]){

			TableRTT[i] = TableTime[i]-RTT[i];
			sumRTT += TableRTT[i];
			number++;

		}else if (TableTime[i] != 0.0 && TableTime[i]<RTT[i]){

			TableRTT[i] = TableTime[i]- (RTT[i]-1000000);
			sumRTT += TableRTT[i];
			number++;
		}

	
	}

	RTTaverage= sumRTT/(number*1.0);

	int k=0;
	while(TableRTT[k] == 0.0){
			k++;

	}

	double RTTmin = TableRTT[k];
	double RTTmax = TableRTT[k];

	for(i=1;i<sent;i++){

		if(TableRTT[i]<RTTmin && TableRTT[i] !=0.0 ){

			RTTmin = TableRTT[i];

		}else if(TableRTT[i]> RTTmax && TableRTT[i] !=0.0 ){
			
			RTTmax = TableRTT[i];

		}


	}

	/*********************************
	CALCULATION OF THE STANDARD DEVIATION
	**********************************/	
	long double sumstadardRTT=0;

	for(i=0;i<sent;i++){

		if(TableRTT[i] != 0.0){

              sumstadardRTT += pow(TableRTT[i]-RTTaverage, 2);

		}


	}

	deviation_RTT = sqrt(sumstadardRTT/number);

	/*********************************
	CALCULATION OF THE SENT BANDWIDTH 
	**********************************/
	sum=0;
	double Through;
	double meanThrough;
	double RTT1[sent-1];
	double numb=0;

	for(i=0;i<sent-1;i++){

		RTT1[i] = RTT[i+1];
	}

	for(i=0;i<sent-1;i++){

		if(RTT1[i]> RTT[i]){

			TableThrough[i] = RTT1[i]- RTT[i];
			sum += TableThrough[i];
			
		}else{

			TableThrough[i] = RTT1[i]-(RTT[i]-1000000);
			sum += TableThrough[i];
		}
			
	}

	meanThrough = sum/(sent-numb);
	Through =(packet_size+Interpacket_gap)*8.0/meanThrough;


	/*********************************
	CALCULATION OF THE BANDWIDTH 
	**********************************/

	sum=0;
	int nu=0;
	double Gap[sent -1];

	for(i=0;i<(sent-1);i++){

		Gap[i] = 0.0;

		if(TableTime[i] != 0.0 && TableTime[i+1] != 0.0 && TableTime[i]<TableTime[i+1]){ 

			Gap[i] = TableTime[i+1]-TableTime[i];
			sum += Gap[i];
			nu++;


		}else if(TableTime[i] != 0.0 && TableTime[i+1] != 0.0 && TableTime[i] > TableTime[i+1] ){

			Gap[i] = TableTime[i+1]- (TableTime[i]-1000000);
			sum+= Gap[i];
			nu++;
	
		}
	}


	


	mean = (sum)/((nu)*1.0);
	BW = (packet_size+Interpacket_gap)*8.0/mean;


	/*********************************
	CALCULATION OF THE GENERAL BANDWIDTH 
	**********************************/

	sum= 0;
	int serie=0;
	for(i=0;i<sent;i++){

		

		if(TableTime[i] != 0 && TableTime[i+1] !=0  && TableTime[i] > TableTime[i+1]){
			 serie++;
		}
		
	}

		general_BW = ((sent-packet_loss)*8.0*packet_size)/(TableTime[sent-1]+(serie*1000000) - TableTime[0]);
	
	
	/*************************************************
	CALCULATION OF THE STANDARD DEVIATION OF BANDWIDTH
	**************************************************/	

	double sumstadardBandwidth=0;
	double Bandwidth[sent-1];

	for(i=0;i<(sent-1);i++){

		if(Gap[i] != 0.0){
				
				Bandwidth[i] = (packet_size+Interpacket_gap)*8.0/Gap[i]; 
  
		}
    

	}

	k=0;
	while(Bandwidth[k] == 0.0){
			k++;
	}

	double Bandwidthmin = Bandwidth[k];
	double Bandwidthmax = Bandwidth[k];

	for(i=0;i<(sent-1);i++){

		if(Bandwidth[i]< Bandwidthmin && Bandwidth[i] !=0.0 ){

			Bandwidthmin = Bandwidth[i];

		}else if(Bandwidth[i]> Bandwidthmax && Bandwidth[i] !=0.0 ){
			
			Bandwidthmax = Bandwidth[i];

		}
	}

	for(i=0;i<(sent-1);i++){

			if(Bandwidth[i] != 0.0){

	              sumstadardBandwidth += pow(Bandwidth[i]-BW, 2);

			}


	}

	double deviation_BW = sqrt(sumstadardBandwidth/nu);





	printf("\n*********************************\n           MEASURES \n*********************************\n");

	printf("Throughput: %F Mbit/s\n",Through);

	printf("RTT min/average/max/time: %f %f %f %Lf microseconds \n",RTTmin/1000.0,RTTaverage/1000.0,RTTmax/1000.0,sumRTT/1000.0);

	printf("Jitter: %Lf microseconds \n",deviation_RTT/1000.0);

	printf("Mean bandwidth: %LF Mbit/s\n",BW);

	printf("General bandwidth: %LF Mbit/s\n",general_BW);

	printf("Bandwidth desviation: %F Mbit/s\n",deviation_BW);

	printf("Bandwidth: min/average/max: %f %LF %f  Mbit/s\n",Bandwidthmin,BW,Bandwidthmax);

	printf("Received packets: %d\nLost packets: %d  %2.2f%% \n",sent -packet_loss,packet_loss, (packet_loss*1.0/sent*1.0)*100.0);
}



char *BuiltUDP(int j,int payload_size,unsigned long daddr){


    packet_size = sizeof(struct ether_header) + sizeof (struct iphdr)  + sizeof (struct udp_hdr) + payload_size;
    char *packet = (char *) malloc (packet_size);
    
    struct ether_header *eh = (struct ether_header *) packet;

    struct iphdr *ip = (struct iphdr *) (packet + sizeof (struct ether_header));
    struct udp_hdr *udp = (struct udp_hdr *) (packet + sizeof (struct iphdr) + sizeof (struct ether_header) );

    memset (packet, 0, packet_size);



    //ETHERNET_HEADER
    eh->ether_shost[0] = Source_mac[0];
    eh->ether_shost[1] = Source_mac[1];
    eh->ether_shost[2] = Source_mac[2];
    eh->ether_shost[3] = Source_mac[3];
    eh->ether_shost[4] = Source_mac[4];
    eh->ether_shost[5] = Source_mac[5];

    eh->ether_dhost[0] = Dest_mac[0];
    eh->ether_dhost[1] = Dest_mac[1];
    eh->ether_dhost[2] = Dest_mac[2];
    eh->ether_dhost[3] = Dest_mac[3];
    eh->ether_dhost[4] = Dest_mac[4];
    eh->ether_dhost[5] = Dest_mac[5];

    eh->ether_type = htons(ETHERTYPE_IP);

    //IP_HEADER 
    ip->version = 4;
    ip->ihl = 5;
    ip->tos = 0;
    ip->tot_len = htons (packet_size - sizeof(struct ether_header));
    ip->id = rand ();
    ip->frag_off = 0;
    ip->ttl = 0x40;
    ip->protocol = IPPROTO_UDP;
    ip->saddr = saddr;
    ip->daddr = daddr;
    //ip->check = 0xcbc8;
    ip->check = in_cksum ((u16 *) ip, sizeof (struct iphdr));

    udp->src_port = 0x3930;
    udp->dst_port[1] = 0x9A + (uint8_t)j; 
    udp->dst_port[0] = 0x82;
    udp->length = htons (packet_size - sizeof(struct ether_header)-sizeof(struct iphdr));
    udp->checksum = 0x0000;
 	memset(packet +sizeof(struct ether_header)+ sizeof(struct iphdr) + sizeof(struct udp_hdr), rand() % 255, payload_size);
    udp->checksum =htons(UDPcheck(packet,payload_size));
	return packet;

}

uint16_t UDPcheck(char *packet,int payload_size){

    int tamano=26;
    uint16_t aux;
    uint16_t answer;
    uint32_t sum= 0x00000011;
    
    while(tamano<39){

        memcpy(&aux,packet+tamano,2);
        sum += htons(aux);
        tamano=tamano+2;
    }

    tamano =38; 
    memcpy(&aux,packet+tamano,2);
    sum += htons(aux);
    
    tamano = 42;

    while(tamano< (42+payload_size)){

        if((42+payload_size)-tamano != 1){

            memcpy(&aux,packet+tamano,2);

        }else{

            aux=0x0000;
            memcpy(&aux,packet+tamano,1);

        }

        sum += htons(aux);
        tamano=tamano+2;
    }


    sum = (sum >> 16) + (sum & 0xffff);
    answer = ~sum;
    return answer;
    

}

char *BuiltICMP(int sequence,int payload_size,unsigned long daddr){


    packet_size = sizeof(struct ether_header) + sizeof (struct iphdr) + sizeof (struct icmphdr) + payload_size;
    char *packet = (char *) malloc (packet_size);

    //ethernet header
    struct ether_header *eh = (struct ether_header *) packet;
    //ip header
    struct iphdr *ip = (struct iphdr *) (packet + sizeof (struct ether_header));
    struct icmphdr *icmp = (struct icmphdr *) (packet + sizeof (struct iphdr) + sizeof (struct ether_header) );

    memset (packet, 0, packet_size);


    //ETHERNET_HEADER
    eh->ether_shost[0] = Source_mac[0];
    eh->ether_shost[1] = Source_mac[1];
    eh->ether_shost[2] = Source_mac[2];
    eh->ether_shost[3] = Source_mac[3];
    eh->ether_shost[4] = Source_mac[4];
    eh->ether_shost[5] = Source_mac[5];

    eh->ether_dhost[0] = Dest_mac[0];
    eh->ether_dhost[1] = Dest_mac[1];
    eh->ether_dhost[2] = Dest_mac[2];
    eh->ether_dhost[3] = Dest_mac[3];
    eh->ether_dhost[4] = Dest_mac[4];
    eh->ether_dhost[5] = Dest_mac[5];

    eh->ether_type = htons(ETHERTYPE_IP);

    //IP_HEADER 
    ip->version = 4;
    ip->ihl = 5;
    ip->tos = 0;
    ip->tot_len = htons (packet_size - sizeof(struct ether_header));
    ip->id = rand ();
    ip->frag_off = 0;
    ip->ttl = 255;
    ip->protocol = IPPROTO_ICMP;
    ip->saddr = saddr;
    ip->daddr = daddr;
    ip->check = in_cksum ((u16 *) ip, sizeof (struct iphdr));

    icmp->type = ICMP_ECHO;
    icmp->code = 0;
    icmp->un.echo.sequence = htons(sequence);
    icmp->un.echo.id = getpid();
    icmp->checksum = 0;

    memset(packet +sizeof(struct ether_header)+ sizeof(struct iphdr) + sizeof(struct icmphdr), 0xfc, payload_size);
    icmp->checksum = 0;
    icmp->checksum = in_cksum((unsigned short *)icmp, sizeof(struct icmphdr) + payload_size);
    
    return packet;
}

unsigned long Checkmask(char * target){

    char errbuf[PCAP_ERRBUF_SIZE];
    char* net;//direccion de red
    char* mask;///mascara de subred
    bpf_u_int32 netp;//direcion de red en modo raw
    bpf_u_int32 maskp;//mascara de red en modo raw
    unsigned long directionIP = inet_addr(target);
    unsigned long result;
    unsigned long network;
    unsigned long masku;

    if((pcap_lookupnet(interface,&netp,&maskp,errbuf)) < 0){
        printf("ERROR %s\n",errbuf);

    }
        addr.s_addr=netp;

    if((net=inet_ntoa(addr))==NULL){
        perror("inet_ntoa");
    }

    network = inet_addr(net);

    addr.s_addr=maskp;
    mask=inet_ntoa(addr);

    if((net=inet_ntoa(addr))==NULL){
        perror("inet_ntoa");
    } 
    
    masku = inet_addr(mask);
    result = (directionIP & masku);
    

    if(network == result){

       
     
       return directionIP;

    }else{
    	
        return getGateway();
    }

}

unsigned long getGateway(){
	 FILE *fp;
   char buff[255];
   char ch[50];
   char flag[4] ={0};
   int tamano = 0;
   unsigned long gateway_address;

   fp = fopen("/proc/net/route", "r");

	while((fgets(buff,255,fp)) != NULL){

		memcpy(ch,buff,strlen(interface));
		tamano =  strlen(interface);

		while(buff[tamano] == ' ' || buff[tamano]  == '\t'){

			tamano++;
		}

		tamano = tamano+8;

		while(buff[tamano] == ' ' || buff[tamano]  == '\t'){

			tamano++;
		} 
    	
    	memcpy(ch,buff+tamano,8);
		tamano = tamano+8;

		while(buff[tamano] == ' ' || buff[tamano]  == '\t'){

			tamano++;

		}

		memcpy(flag,buff+tamano+1,3);

		if(memcmp("003",flag,3)==0){

			gateway_address = (unsigned long)strtol(ch, NULL, 16);

		}

		tamano = 0;
    }
return gateway_address;

fclose(fp);

}

char *BuiltARP(unsigned long daddr){

	uint8_t Broadcast[ETH_ALEN]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

 	packet_size = sizeof(struct ether_header) + sizeof (struct arp_hdr);
 	
    char *packet = (char *) malloc (packet_size);
    struct ether_header *arp = (struct ether_header *) packet;
    struct arp_hdr* arpa = (struct  arp_hdr *) (packet + sizeof (struct ether_header));

    memset (packet, 0, packet_size);

	arp->ether_shost[0] = Source_mac[0];
    arp->ether_shost[1] = Source_mac[1];
    arp->ether_shost[2] = Source_mac[2];
    arp->ether_shost[3] = Source_mac[3];
    arp->ether_shost[4] = Source_mac[4];
    arp->ether_shost[5] = Source_mac[5];


	arp->ether_dhost[0] = Broadcast[0];
	arp->ether_dhost[1] = Broadcast[1];
	arp->ether_dhost[2] = Broadcast[2];
	arp->ether_dhost[3] = Broadcast[3];
	arp->ether_dhost[4] = Broadcast[4];
	arp->ether_dhost[5] = Broadcast[5];

	arp->ether_type = htons(ETHERTYPE_ARP);

	arpa->hardware_type = 0x0100;
	arpa->protocol_type = 0x0008;		
	arpa->hardware_addres_length =0x06;	
	arpa->protocol_addres_length =0x04;
	arpa->opcode =0x0100;

	arpa->senderMac[0] = Source_mac[0];;
	arpa->senderMac[1] = Source_mac[1];;
	arpa->senderMac[2] = Source_mac[2];;
	arpa->senderMac[3] = Source_mac[3];;
	arpa->senderMac[4] = Source_mac[4];;
	arpa->senderMac[5] = Source_mac[5];;
   	 
   	arpa->senderIP[0]= saddr;
   	arpa->senderIP[1]= (saddr)>>16;
	
	arpa->destinationMac[0] =0x00;
	arpa->destinationMac[1] =0x00;
	arpa->destinationMac[2] =0x00;
	arpa->destinationMac[3] =0x00;
	arpa->destinationMac[4] =0x00;
	arpa->destinationMac[5] =0x00;

	arpa->destinationIP[0]=  daddr;
   	arpa->destinationIP[1]= daddr>>16;

    return packet;
}


void wait(){
	uint8_t dest[ETH_ALEN]={0};
	while(memcmp(dest,Dest_mac,6)==0);	
}


double sendPacket(char *packet){
	
    if (pcap_inject(per,packet,packet_size) != packet_size) 
    {
        perror("send failed\n");
        return 1;
    }

    return 0;

}

unsigned short in_cksum(unsigned short *ptr, int nbytes)
{
    register long sum;
    u_short oddbyte;
    register u_short answer;

    sum = 0;
    while (nbytes > 1) {
        sum += *ptr++;
        nbytes -= 2;
    }

    if (nbytes == 1) {
        oddbyte = 0;
        *((u_char *) & oddbyte) = *(u_char *) ptr;
        sum += oddbyte;
    }

    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = ~sum;

    return (answer);
}

int finalizar()
{

	if (StartFrame == 1){
		pcap_breakloop(per);
		pcap_close(per);
		return 0;

	}

	return 1;

}
