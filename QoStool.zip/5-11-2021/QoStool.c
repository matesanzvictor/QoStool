
/*################################################################################
# Autor: Víctor Matesanz Cotillas
# Fecha: 11/05/2021
################################################################################*/

#include <stdio.h>
#include <time.h>
#include "function1.h"


int main(int argc, char *argv[])
{

  
	int sent=0;
	int payload_size = 1400;
	int train_len = 50;//packets
	double speed = 10;//Mbit/s
	int type = 0;//icmp
	unsigned long target = inet_addr(argv[1]);
	unsigned long ARPtarget;
	struct timespec interval;
	interval.tv_sec=0;
	int Interpacket_gap = 0;


	if(argc<1){
		printf("Error: faltan argumentos pulsa -h para ayuda \n");
	return -1;
	}

	for(int i =1; i<argc; i++){

		if(memcmp("-p",argv[i],strlen(argv[i]))==0){
			payload_size = atoi(argv[i+1]);

		}else if(memcmp("-l",argv[i],strlen(argv[i]))==0){

			if(MAX_STRUCTURE > atoi(argv[i+1])){
			train_len = atoi(argv[i+1]);

			}else{
			train_len = MAX_STRUCTURE;
			}
		
		}else if(memcmp("-s",argv[i],strlen(argv[i]))==0){
			speed = atof(argv[i+1]);

		}else if(memcmp("--udp",argv[i],strlen(argv[i]))==0){
			type = 1;

		}else if(memcmp("--icmp",argv[i],strlen(argv[i]))==0){
			type = 0;

		}else if(memcmp("-h",argv[i],strlen(argv[i]))==0){
			char *ayuda = 
		    "Help:\n" 
		    "  -h       Help\n"
		    "  -l       Packets(1000 max)\n"
		    "  -p       Payload size\n"
		    "  -s       Speed (Mbit/S)\n"
		    "  -i       Interpacket_gap (24 Bytes recommended)\n"
		    "  --icmp   Type icmp\n"
		    "  --udp    Type Udp\n\n"
		    "example: sudo ./QoStool 192.168.1.1 -l 10 -s 0.5 -p 1472 -i 24 --icmp \n"; 

			fprintf(stderr,"%s\n", ayuda);

			return -1;


		}else if(memcmp("-i",argv[i],strlen(argv[i]))==0){
			Interpacket_gap = atoi(argv[i+1]);

		}

	}
	
	printf("Target: %s \n",argv[1]);
	printf("Payload: %d Bytes\npackets: %d \n",payload_size,train_len);

	if (speed != 0){
		interval.tv_nsec = (payload_size + Interpacket_gap)*8/speed*1000;
		printf("Speed: %f Mbit/s\n",speed);

	}else {

		interval.tv_nsec = 0;
		printf("Speed: Max \n");
	}

	if(type == 0) {printf("Type: ICMP \n");}
	if(type == 1) {printf("Type: UDP \n");}

	if(StartProgram() == 1){

		printf("Error al iniciar el programa");
		return -1;
	}

	getMacIP();

	Startcapture();  

	ARPtarget = Checkmask(argv[1]);   

	char* packetARP = BuiltARP(ARPtarget);

	if(sendPacket(packetARP)==1){

	  printf("Error al enviar el paquete ARP %d \n",sent);
	}

	wait();//espera a encontrar la MAC

	int j;
	char *packet[train_len];

	if(type == 1){

		for(j=0;j<train_len;j++){
			packet[j] = BuiltUDP(j,payload_size,target);
		}

		printf("%d packets sent \r", j);
	    fflush(stdout);

	}else{

		for(j=0;j<train_len;j++){
			packet[j] = BuiltICMP(j,payload_size,target);
		}

		printf("%d packets sent \r", j);
	    fflush(stdout);

	}

	struct timeval tv;
	double RTT[train_len];


	if(interval.tv_nsec != 0){

	 	while (sent < train_len)
		  {

			gettimeofday(&tv, NULL);
	  
		    if(sendPacket(packet[sent])==1){
		      	printf("Error al enviar el paquete\n");
		    }

			RTT[sent] = tv.tv_usec;
		    ++sent; 
		    nanosleep(&interval,NULL);  
		  }

	}else{

		while (sent < train_len)
	  	{
			gettimeofday(&tv, NULL);
	     	
		    if(sendPacket(packet[sent])==1){
		      printf("Error al enviar el paquete\n");
		    }

			RTT[sent] = tv.tv_usec;

		    ++sent;
	  	}
	}

	sleep(5);

	Measures(sent,RTT,Interpacket_gap);

	if(finalizar()==0){

		printf("Program finished successfully\n");

	}else

		printf("Error al finalizar\n");

	return -1;
}


