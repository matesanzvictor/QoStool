/*################################################################################
# Autor: Víctor Matesanz Cotillas
# Fecha: 11/05/2021
################################################################################*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h> 
#include <string.h>
#include <pcap.h>
#include <netinet/in.h>
#include <errno.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/ether.h>

#define ETH_ALEN 6
#define HWADDR_len 6
#define IP_ALEN 4
#define MAX_STRUCTURE 1000

typedef unsigned char u8;
typedef unsigned short int u16;

struct arp_hdr	
{	
uint16_t hardware_type;	
uint16_t protocol_type;	
uint8_t hardware_addres_length;	
uint8_t protocol_addres_length;
uint16_t opcode;
uint8_t senderMac[ETH_ALEN];
uint16_t senderIP[2];
uint8_t destinationMac[ETH_ALEN];
uint16_t destinationIP[2];
};

struct udp_hdr
{
uint16_t src_port;
uint8_t dst_port[2];
uint16_t length;
uint16_t checksum;
};

unsigned short in_cksum(unsigned short *ptr, int nbytes);

int StartProgram();

void wait();

char *BuiltUDP(int j,int payload_size,unsigned long daddr);

char *BuiltICMP(int sequence,int payload_size,unsigned long daddr);

char*  BuiltARP(unsigned long daddr);

void Startcapture();

void Measures(int sent,double RTT[sent],int Interpacket_gap);

void getMacIP();

double sendPacket(char *packet);

unsigned long Checkmask(char * target);

unsigned long getGateway();

uint16_t UDPcheck(char *packet,int payload_size);

int finalizar();
